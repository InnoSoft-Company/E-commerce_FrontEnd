import { Product } from "@/src/data/products";
import { Star } from "lucide-react";

export default function Info({ product }: { product: Product }) {
  return (
    <>
      <p style={{ fontSize: "11px", fontWeight: 800, letterSpacing: "0.28em", textTransform: "uppercase", color: "#d97706", marginBottom: "12px", display: "flex", alignItems: "center", gap: "8px" }}>
        <span style={{ width: "20px", height: "2px", background: "#f59e0b", display: "inline-block", borderRadius: "2px" }} />
        {product.category}
      </p>

      <h1 style={{ fontFamily: "var(--font-cormorant, Georgia, serif)", fontSize: "clamp(2rem, 4vw, 3.2rem)", fontWeight: 800, color: "#0f172a", lineHeight: 1.05, marginBottom: "16px" }}>
        {product.name}
      </h1>

      <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "20px" }}>
        <div style={{ display: "flex", gap: "2px" }}>
          {[...Array(5)].map((_, i) => (
            <Star key={i} style={{ width: "16px", height: "16px", color: i < Math.floor(product.rating) ? "#f59e0b" : "#e2e8f0" }} fill={i < Math.floor(product.rating) ? "#f59e0b" : "none"} strokeWidth={1} />
          ))}
        </div>
        <span style={{ fontSize: "14px", color: "#64748b", fontWeight: 500 }}>{product.rating} ({product.reviews} تقييم)</span>
      </div>

      <p style={{ fontFamily: "var(--font-cormorant, Georgia, serif)", fontSize: "2.4rem", fontWeight: 800, color: "#0f172a", marginBottom: "20px" }}>
        ${product.price.toFixed(2)}
      </p>

      <div style={{ borderTop: "2px solid #f1e4b8", paddingTop: "20px", marginBottom: "20px" }}>
        <p style={{ fontSize: "16px", color: "#334155", fontWeight: 400, lineHeight: 1.75 }}>{product.description}</p>
      </div>
    </>
  );
}
