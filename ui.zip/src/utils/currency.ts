/**
 * تحويل السعر من دولار إلى جنيه مصري وعرضه بالعربي
 * السعر في قاعدة البيانات بالدولار — نضرب في 50
 */
export const USD_TO_EGP = 50;

export function toEGP(usd: number | string): number {
  return Math.round(parseFloat(String(usd)) * USD_TO_EGP);
}

export function formatPrice(usd: number | string): string {
  const egp = toEGP(usd);
  return egp.toLocaleString("ar-EG") + " ج.م";
}

export function formatPriceRaw(usd: number | string): string {
  return toEGP(usd).toLocaleString("ar-EG");
}
